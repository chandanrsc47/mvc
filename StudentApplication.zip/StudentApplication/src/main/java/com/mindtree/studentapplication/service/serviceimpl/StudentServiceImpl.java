package com.mindtree.studentapplication.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.studentapplication.dto.ClassesDto;
import com.mindtree.studentapplication.dto.StudentDto;
import com.mindtree.studentapplication.entity.Classes;
import com.mindtree.studentapplication.entity.Student;
import com.mindtree.studentapplication.repository.ClassesRepository;
import com.mindtree.studentapplication.repository.StudentRepository;
import com.mindtree.studentapplication.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private ClassesRepository classesRepository;

	private ModelMapper mapper = new ModelMapper();

	@Override
	public String addStudent(StudentDto studentDto, String section) {
		List<Classes> classesList = classesRepository.findAll();
		Student student = mapper.map(studentDto, Student.class);
		Classes classes = classesList.stream().filter(i -> i.getSection().equalsIgnoreCase(section)).findAny().get();
		List<Student> students = classes.getStudents();
		if (students.size() < classes.getNoOfStudents()) {
			classes.getStudents().add(student);
			classesRepository.save(classes);
		}

		return "inserted";
	}

	@Override
	public ClassesDto getStudentDetails(String section) {
		List<StudentDto> studentDto = new ArrayList<StudentDto>();
		List<Classes> classesList = classesRepository.findAll();
		Classes classes = classesList.stream().filter(i -> i.getSection().equalsIgnoreCase(section)).findAny().get();
		for (Student student : classes.getStudents()) {
			StudentDto students = mapper.map(student, StudentDto.class);
			studentDto.add(students);

		}
		ClassesDto classesDto = mapper.map(classes, ClassesDto.class);

		return classesDto;
	}

}
