package com.mindtree.studentapplication.service.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.studentapplication.dto.ClassesDto;
import com.mindtree.studentapplication.entity.Classes;
import com.mindtree.studentapplication.repository.ClassesRepository;
import com.mindtree.studentapplication.service.ClassesService;

@Service
public class ClassesServiceImpl implements ClassesService {

	@Autowired
	private ClassesRepository classesRepository;

	private ModelMapper mapper = new ModelMapper();

	@Override
	public String insertClassDetails(ClassesDto classesDto) {

		Classes classes = mapper.map(classesDto, Classes.class);
		classesRepository.save(classes);
		return "insert class";
	}
}
