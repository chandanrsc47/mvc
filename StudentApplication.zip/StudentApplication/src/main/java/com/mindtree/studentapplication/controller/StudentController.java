package com.mindtree.studentapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.studentapplication.dto.ClassesDto;
import com.mindtree.studentapplication.dto.StudentDto;
import com.mindtree.studentapplication.service.ClassesService;
import com.mindtree.studentapplication.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private ClassesService classesService;

	@Autowired
	private StudentService studentService;

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping("/classinsert")
	public String classInsert() {
		return "insertclass";
	}

	@RequestMapping("/classdetails")
	public String insertClassDetails(ClassesDto classesDto) {
		classesService.insertClassDetails(classesDto);
		return "message";
	}

	@RequestMapping("/getclasssection")
	public String getClassSection() {
		return "getsection";
	}
	
	@PostMapping("/addstudent")
	public String addStudent(StudentDto studentDto, @RequestParam String section) {
		
		studentService.addStudent(studentDto,section);
		return "message";
		
	}
	@RequestMapping("/getsection")
	public String getSection() {
		return "getsections";
	}

	@GetMapping("/getstudents")
	public String getStudentDetails(@RequestParam String section, Model model) {
		ClassesDto classesDto = studentService.getStudentDetails(section);
		model.addAttribute("classesDto", classesDto);
		return "getsections";
	}
}
