package com.mindtree.studentapplication.service;

import com.mindtree.studentapplication.dto.ClassesDto;
import com.mindtree.studentapplication.dto.StudentDto;

public interface StudentService {

	/**
	 * @param section
	 * @return class details
	 */
	
	public ClassesDto getStudentDetails(String section);

	/**
	 * @param studentDto
	 * @param section
	 * @return string
	 */
	public String addStudent(StudentDto studentDto, String section);

}
