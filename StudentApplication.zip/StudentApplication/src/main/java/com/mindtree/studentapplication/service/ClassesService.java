package com.mindtree.studentapplication.service;

import com.mindtree.studentapplication.dto.ClassesDto;

public interface ClassesService {

	/**
	 * @param classesDto
	 * @return string
	 */
	
	public String insertClassDetails(ClassesDto classesDto);

}
